# Chaos Party RPG

Private project for a family TV-and-phones, AI-assisted, chaotic fantasy party game.

**Local Qwen integration:** the multiplayer server now has an optional local AI action interpreter. [Connection, test evidence and current model-download blocker](docs/LOCAL_AI.md). The model itself has not been installed or verified in this cloud session.

**Status: 0.3 beta candidate — one tavern and a complete cooperative crown heist.** The scene has 46 addressable objects with persistent changes, material-based checks, cover, hazards, NPC health and situational advantage/disadvantage. [Beta notes](docs/BETA.md) explain what is playable and what still needs real hardware testing. Source provenance remains in [docs/PROTOTYPE_IMPORT.md](docs/PROTOTYPE_IMPORT.md).

Use Node 22+, run `npm ci`, then `npm start`. Open the host screen on the server machine at port 4747 and join from phone browsers on the same LAN. For a real phone test without the Mac, use the [Codespaces live-game instructions](docs/PHONE_REAL_GAME.md). `npm test` exercises multiplayer and saves; `npm run build` produces the separate static solo preview. No paid API is required, though Codespaces may use an account’s included quota or billable minutes.

## Target experience
- One shared full-screen 16:9 pixel-art tavern on TV; 12–20+ players connect from phone browsers using a QR or room code.
- Every player creates and keeps a personalized sprite character, clothing, name, class, equipment and progression.
- No phone joystick controls. Players type or dictate free-form, chaotic actions. First valid action locks and is announced; others get 8–12 seconds to react. Actions may fail on a fair dice roll and consequences persist.
- Actual animated character motions, hits, knockback, effects, sound, and short entertaining narration. AI interprets free-text; deterministic server owns game state. Run without paid AI credentials using a transparently labeled fallback.
- Host on an early-2015 13-inch Intel MacBook Pro (dual-core i5, 8 GB RAM, Iris 6100) via HDMI if performance allows; benchmark before promising it will work.

## Critical development constraint
**Reuse first. Never blindly generate another generic game-looking website from scratch.** Find and actually run complete existing games, evaluate their licenses and architecture, compare before selecting the playable foundation. Preserve existing working multiplayer code while replacing inadequate visual/gameplay sections. No copyrighted DungeonBox extraction.

## Instructions
1. Read AGENTS.md and docs/REUSE_CANDIDATES.md.
2. Read docs/CODEX_KICKOFF.md and docs/PROTOTYPE_IMPORT.md. Preserve the recovered source and existing saves. If the original archive becomes available, keep a pristine copy and scan before committing.
3. Run and visually evaluate both TV and phone experiences; capture screenshots/video.
4. Make a runnable *visual* tavern spike. Compare it with an actually running licensed game. Favor reusing character animations and world rendering from an established playable game.
5. Demonstrate a complete 90-second chaotic interaction on two real phone browsers with the TV screen, plus 20-client simulated load tests.
6. Do not claim the game is finished solely on tests passing. No new costs, public deployments, or changes to unrelated repositories without authorization.

Useful foundations and license considerations: see docs/REUSE_CANDIDATES.md.
