#!/bin/bash
set -eu
game_dir="$(cd "$(dirname "$0")" && pwd)"
case "$(uname -m)" in
  arm64) game_arch="arm64" ;;
  x86_64) game_arch="x64" ;;
  *) echo "This build supports Intel and Apple Silicon Macs."; read -r -p "Press Return to close."; exit 1 ;;
esac
export CHAOS_LAUNCH=1
export CHAOS_OPEN=1
export CHAOS_DATA_DIR="$HOME/Library/Application Support/Chaos Party"
cd "$game_dir"
if ! "$game_dir/runtime/$game_arch/node" "$game_dir/server.cjs"; then
  echo ""
  echo "The tavern could not start. See the message above."
  read -r -p "Press Return to close."
fi
